# Bareos WebUI

PHP-Frontend to monitor and manage Bareos.
