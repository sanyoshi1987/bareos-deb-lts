Bareos WebUI Translation
========================

### Where do I find the translation?

The localization files are located in `module/Application/language`. You can find the languages that are currently
in translation in our online project, which is addressed in the next section.

### How should I edit translation files?

You need to join our online project for translating the Bareos WebUI. We use http://poeditor.com.
The following link, https://poeditor.com/join/project/ELnLNbvQJb , will redirect you to the right project.
You can join our translation community as a contributor there.

### How can I add a new language?
We will add the feature to add a new lanugage as a contributor after the existing localizations have been completed.
Check back in a while to see if it's possible then.

### Where can I find further information?

See [here](https://poeditor.com/features/) for more info on POEditor.

### What if my questions are not answered in this document?

Do not be afraid to ask them on our mailinglist, bareos-devel@googlegroups.com .
